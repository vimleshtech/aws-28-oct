def wel():
    print('test function program. ..')
    
def add(a,b):
    c =a+b
    print(c)





wel()
add(11,3)
add(1,55)
