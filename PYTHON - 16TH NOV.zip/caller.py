import mylib

mylib.create_file('emp.txt','this test emp file')
mylib.read_file('emp.txt')

