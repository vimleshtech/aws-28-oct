for x in range(1,10):
    print(x)

#break
    
for x in range(1,10):
    #if x%3 ==0:
    if x ==3:
        break 
    print(x)

#continue
for x in range(1,10):
    if x%3 ==0:    
        continue
    print(x)

    


